

/**
 * 
 * @author Kidus Tilahun
 *
 */
public enum Format {
  IMAX, THREE_D, NONE
}
